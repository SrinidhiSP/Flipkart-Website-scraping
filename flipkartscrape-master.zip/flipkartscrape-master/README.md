# flipkartscrape
webscraping item name, category and price from flipkart.com with the help of beautiful soup.
This program basically webscrapes product details provided the flipkart url.

The url should be of the form
https://www.flipkart.com/<category>/********
